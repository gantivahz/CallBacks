const nombre = "Luis";
const equipo = "Liverpool";
const edad = 26;

const jugador = { nombre, equipo, edad };

console.log(jugador);
