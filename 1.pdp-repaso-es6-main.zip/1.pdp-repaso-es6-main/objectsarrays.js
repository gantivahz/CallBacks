/**
 * Object conjunto de propiedades (clave:valor)
 */

const persona = { nombre: "Juan", estado: true };
console.log(persona);
console.log(persona.nombre);
persona.estado = false;
console.log(persona);
persona.apellido = "Perez";
console.log(persona);
/**
 * Array conjunto de elementos
 */

const numeros = [3, 4, 5, 6];
console.log(numeros[0]);
numeros.push(true);
console.log(numeros);
