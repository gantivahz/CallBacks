const jugador = "Messi";
const equipo = "PSG";

const message = "El jugador " + jugador + " juega en el equipo " + equipo;

console.log(message);

const message2 = `El jugador ${jugador} juega en el equipo
${equipo}`;

console.log(message2);
